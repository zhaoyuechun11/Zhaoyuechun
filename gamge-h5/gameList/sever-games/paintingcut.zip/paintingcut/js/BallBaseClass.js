'use strict';

function BallClass() {
    //this.speed;
}

BallClass.prototype.Create = function () {
    
}