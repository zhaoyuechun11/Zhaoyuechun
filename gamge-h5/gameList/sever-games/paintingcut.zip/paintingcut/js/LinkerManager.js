'use strict';

var uiManager = _uiManager.Instance;
var figureManager = _figureManager.Instance;
var actionManager = _actionManager.Instance;
var assetManager = _assetManager.Instance;
var stageManager = _stageManager.Instance;
var feverManager = _feverManager.Instance;
var ballManager = _ballManager.Instance;
var userItemManager = _userItemManager.Instance;
var buffItemManager = _buffItemManager.Instance;
var bombEffecter = _bombEffecter.Instance;
var stateManager = _stateManager.Instance;
var shopManager = _shopManager.Instance;